# حالت نظارت خودکار | Auto-Watch Mode

<div dir="rtl">

## 🔍 حالت نظارت خودکار چیست؟

با این حالت، دیگر نیازی نیست دستی فایل‌ها را به برنامه بدهید!

**فقط کافیست:**
1. برنامه را اجرا کنید
2. فایل‌های ویدیو را در پوشه `input` بگذارید
3. برنامه به صورت خودکار آنها را تبدیل می‌کند! ✨

</div>

---

## 🚀 نحوه استفاده

### روش آسان (توصیه می‌شود):

```bash
./start_watch.sh
```

### یا روش دستی:

```bash
python3 auto_watch.py
```

---

## 📁 ساختار پوشه‌ها

```
/home/hossein/antigravit/
├── input/              ← فایل‌های ویدیو را اینجا بگذارید
│   ├── _processed/     ← فایل‌های با موفقیت تبدیل شده
│   └── _failed/        ← فایل‌های ناموفق (مثلاً فرمت نامعتبر)
│
└── output/             ← فایل‌های x265 تبدیل شده
    ├── movies/
    ├── series/
    └── anime/
```

---

## 📝 مثال کاربردی

### مرحله 1: شروع نظارت

```bash
cd /home/hossein/antigravit
./start_watch.sh
```

خروجی:
```
════════════════════════════════════════════════════════════
      🔍 حالت نظارت خودکار - Auto Watch Mode
════════════════════════════════════════════════════════════

🔍 حالت نظارت خودکار فعال شد
📌 فایل‌های ویدیو را در این پوشه قرار دهید:
   /home/hossein/antigravit/input

💡 برنامه هر 5 ثانیه پوشه را بررسی می‌کند
⏸️  برای توقف: Ctrl+C
```

### مرحله 2: اضافه کردن فایل‌ها

در یک terminal دیگر:

```bash
# کپی فایل به پوشه input
cp ~/Downloads/movie.mp4 /home/hossein/antigravit/input/

# یا با drag & drop در file manager
```

### مرحله 3: تماشای تبدیل خودکار! 🎉

```
🔔 1 فایل جدید یافت شد!

============================================================
🆕 فایل جدید شناسایی شد: movie.mp4
============================================================
⏳ در انتظار کامل شدن کپی فایل...

✓ اعتبارسنجی موفق: movie.mp4
نوع: movie
کیفیت: 1080p

تبدیل | سرعت: 45fps | زمان: 00:05:23 | باقیمانده: 00:12:45
  75%|████████████████████▌     | 75.0/100%

✓ تبدیل موفق
✅ فایل اصلی منتقل شد به: _processed/movie.mp4
```

---

## ⚙️ تنظیمات پیشرفته

### تغییر زمان بررسی (پیش‌فرض: 5 ثانیه)

```bash
python3 auto_watch.py --interval 10  # هر 10 ثانیه بررسی کند
```

### نظارت پوشه سفارشی

```bash
python3 auto_watch.py --watch /custom/folder
```

### تغییر پوشه خروجی

```bash
python3 auto_watch.py --output /media/converted
```

### ترکیب همه گزینه‌ها

```bash
python3 auto_watch.py --watch /downloads --output /media/x265 --interval 10
```

---

## 🎯 ویژگی‌های حالت نظارت

✅ **نظارت خودکار** - هر 5 ثانیه پوشه را چک می‌کند  
✅ **تبدیل خودکار** - بدون دخالت کاربر  
✅ **مدیریت فایل‌ها** - جابجایی خودکار به _processed یا _failed  
✅ **تشخیص کپی کامل** - منتظر می‌ماند تا فایل کامل کپی شود  
✅ **پردازش دسته‌ای** - چند فایل همزمان پشتیبانی می‌شود  
✅ **لاگ کامل** - ثبت همه عملیات در logs/  

---

## 🔄 جریان کار | Workflow

```
1. کاربر فایل را در input/ می‌گذارد
         ↓
2. برنامه فایل جدید را تشخیص می‌دهد
         ↓
3. منتظر کامل شدن کپی می‌ماند
         ↓
4. اعتبارسنجی می‌کند
         ↓
5. تبدیل به x265 می‌کند
         ↓
6. بررسی سلامت خروجی
         ↓
7a. موفق → انتقال به input/_processed/
7b. ناموفق → انتقال به input/_failed/
         ↓
8. فایل تبدیل شده در output/ ذخیره می‌شود
```

---

## 💡 موارد استفاده

### 1. Download Manager Integration

وقتی دانلودتان تمام شد، خودکار در پوشه `input` ذخیره کنید.

### 2. Network Folder

پوشه `input` را share کنید، از سایر کامپیوترها فایل بگذارید.

### 3. Automated Server

برنامه را همیشه روشن بگذارید، سرور تبدیل خودکار!

### 4. Backup & Convert

فایل‌های قدیمی را کپی کنید، خودکار تبدیل می‌شوند.

---

## ⚠️ نکات مهم

### 1. فایل‌های بزرگ

برای فایل‌های بزرگ (>4GB)، برنامه منتظر می‌ماند تا کپی کامل شود.

### 2. فایل‌های تکراری

اگر فایل با نام مشابه وجود داشته باشد، `_1`, `_2` ... اضافه می‌شود.

### 3. در حال اجرا نگه داشتن

برای استفاده مداوم، از `screen` یا `tmux` استفاده کنید:

```bash
# شروع session
screen -S x265watch

# اجرای برنامه
./start_watch.sh

# Detach: Ctrl+A و سپس D
# Attach مجدد:
screen -r x265watch
```

### 4. Systemd Service (برای اجرای همیشگی)

ایجاد `/etc/systemd/system/x265-watch.service`:

```ini
[Unit]
Description=x265 Video Converter Auto Watch
After=network.target

[Service]
Type=simple
User=hossein
WorkingDirectory=/home/hossein/antigravit
ExecStart=/usr/bin/python3 /home/hossein/antigravit/auto_watch.py
Restart=always

[Install]
WantedBy=multi-user.target
```

فعال‌سازی:
```bash
sudo systemctl enable x265-watch
sudo systemctl start x265-watch
sudo systemctl status x265-watch
```

---

## 📊 مثال عملی

### Terminal 1: شروع برنامه

```bash
$ ./start_watch.sh

🔍 حالت نظارت خودکار فعال شد
📌 فایل‌ها را در /home/hossein/antigravit/input بگذارید
⏸️  برای توقف: Ctrl+C
```

### Terminal 2: اضافه کردن فایل‌ها

```bash
$ cp ~/Downloads/*.mp4 /home/hossein/antigravit/input/
```

### Terminal 1: خروجی خودکار

```
🔔 3 فایل جدید یافت شد!

🆕 movie1.mp4
✓ تبدیل موفق → _processed/

🆕 series_S01E01.mkv
✓ تبدیل موفق → _processed/

🆕 invalid.txt
❌ فرمت نامعتبر → _failed/

📊 تعداد پردازش شده: 3
```

---

## 🛠️ عیب‌یابی

### برنامه فایل جدید را تشخیص نمی‌دهد

- مطمئن شوید فایل در پوشه `input` (نه زیرپوشه) است
- صبر کنید تا یک چرخه بررسی (5 ثانیه) بگذرد

### فایل‌ها به _failed منتقل می‌شوند

- لاگ را بررسی کنید: `cat logs/errors.log`
- فرمت فایل را چک کنید
- کیفیت ویدیو باید حداقل 720p باشد

### برنامه خیلی منابع مصرف می‌کند

- زمان بررسی را افزایش دهید: `--interval 30`
- یا از حالت `--no-resource-check` استفاده کنید

---

## 📖 مستندات بیشتر

- **README.md** - راهنمای کامل برنامه
- **INSTALLATION.md** - نصب در سیستم‌های مختلف
- **QUICK_REFERENCE.md** - مرجع سریع

---

<div align="center" dir="rtl">

**✨ حالت نظارت خودکار - راحت‌ترین راه تبدیل ویدیو! ✨**

**Auto-Watch Mode - The Easiest Way to Convert Videos!**

</div>
