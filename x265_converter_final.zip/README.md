# x265 Video Converter | تبدیل‌کننده ویدیو به x265

<div dir="rtl">

ابزار جامع و پیشرفته برای تبدیل فایل‌های ویدیویی به فرمت x265 (HEVC) با قابلیت‌های زیر:

- ✅ تشخیص خودکار کیفیت ویدیو و اعمال تنظیمات بهینه
- ✅ پردازش دسته‌ای چندین فایل به صورت همزمان
- ✅ دسته‌بندی هوشمند فایل‌ها (فیلم، سریال، انیمه)
- ✅ نمایش نوار پیشرفت زنده با آمار تفصیلی
- ✅ **حالت نظارت خودکار** - فایل بگذارید، خودکار تبدیل می‌شود!
- ✅ مدیریت هوشمند منابع سیستم
- ✅ بررسی خودکار سلامت فایل‌های خروجی
- ✅ پشتیبانی کامل از زبان فارسی
- ✅ ثبت رویدادها و خطاها در فایل لاگ

</div>

---

## Features

A comprehensive Python-based tool for converting video files to x265 (HEVC) format with:

- ✅ Automatic quality detection and optimal preset selection
- ✅ Batch processing with beautiful progress bars
- ✅ Intelligent file categorization (Movies, Series, Anime)
- ✅ Real-time conversion statistics
- ✅ **Auto-Watch Mode** - Drop files and forget, auto-converts!
- ✅ System resource management
- ✅ Output file verification
- ✅ Full Persian language support
- ✅ Comprehensive logging

---

## Installation | نصب

### Prerequisites | پیش‌نیازها

<div dir="rtl">

1. **Python 3.8 یا بالاتر**
   ```bash
   python3 --version
   ```

2. **FFmpeg** (باید در PATH سیستم باشد)
   ```bash
   # Ubuntu/Debian
   sudo apt update
   sudo apt install ffmpeg
   
   # macOS
   brew install ffmpeg
   
   # بررسی نصب
   ffmpeg -version
   ```

</div>

### Install Dependencies | نصب وابستگی‌ها

```bash
cd /home/hossein/antigravit
pip install -r requirements.txt
```

Or install manually:
```bash
pip install tqdm psutil
```

---

## Usage | نحوه استفاده

<div dir="rtl">

### تبدیل یک فایل

```bash
python video_converter.py video.mp4
```

### تبدیل چند فایل

```bash
python video_converter.py video1.mp4 video2.mkv video3.avi
```

### تبدیل تمام فایل‌های یک پوشه

```bash
python video_converter.py /path/to/videos/
```

### استفاده از wildcards

```bash
python video_converter.py *.mp4
```

### تعیین پوشه خروجی سفارشی

```bash
python video_converter.py video.mp4 --output /my/custom/output
```

### تبدیل بدون بررسی خروجی

```bash
python video_converter.py video.mp4 --no-verify
```

### نمایش اطلاعات تفصیلی (دیباگ)

```bash
python video_converter.py video.mp4 --verbose
```

### نمایش راهنما

```bash
python video_converter.py --help
```

---

## 🔍 حالت نظارت خودکار | Auto-Watch Mode

### روش آسان‌تر: فقط فایل بگذارید!

```bash
# شروع حالت نظارت
./start_watch.sh

# یا:
python3 auto_watch.py
```

**سپس فایل‌ها را در پوشه `input` بگذارید و برنامه خودکار آنها را تبدیل می‌کند!** 🎉

```
input/              ← فایل‌ها را اینجا بگذارید
├── _processed/     ← فایل‌های موفق منتقل می‌شوند
└── _failed/        ← فایل‌های ناموفق

output/             ← فایل‌های تبدیل شده (x265)
```

📖 **راهنمای کامل:** [AUTO_WATCH.md](AUTO_WATCH.md)


</div>

---

## Output Structure | ساختار خروجی

<div dir="rtl">

برنامه به صورت خودکار فایل‌ها را دسته‌بندی می‌کند:

</div>

```
output/
├── movies/              # فیلم‌ها
│   └── [movie_name]/
│       └── movie_name.mkv
├── series/              # سریال‌ها
│   └── [series_name]/
│       ├── S01/         # فصل 1
│       │   ├── episode1.mkv
│       │   └── episode2.mkv
│       └── S02/         # فصل 2
│           └── episode1.mkv
└── anime/               # انیمه‌ها
    └── [anime_name]/
        └── episode.mkv
```

---

## Quality Presets | تنظیمات کیفیت

<div dir="rtl">

برنامه به صورت خودکار بر اساس رزولوشن ویدیو، تنظیمات بهینه را اعمال می‌کند:

</div>

| Quality | Resolution | CRF | Preset | Action |
|---------|-----------|-----|--------|--------|
| **720p** | 1280×720 | 23 | medium | تبدیل مستقیم |
| **1080p** | 1920×1080 | 28 | slow | تبدیل مستقیم |
| **>1080p** | 2K/4K | 28 | slow | کاهش به 1080p |
| **<720p** | SD | - | - | رد می‌شود |

<div dir="rtl">

- ویدیوهایی با کیفیت کمتر از 720p **رد می‌شوند**
- ویدیوهایی با کیفیت بالاتر از 1080p به صورت خودکار **به 1080p کاهش می‌یابند** تا حجم فایل بهینه شود
- تنظیمات صدا: **AAC 192k** (استریو یا چند کاناله)

</div>

---

## Features Details | جزئیات قابلیت‌ها

### 1. File Validation | اعتبارسنجی فایل

<div dir="rtl">

- بررسی وجود فایل
- بررسی فرمت‌های پشتیبانی شده (.mp4, .mkv, .avi, .mov, .flv, etc.)
- تشخیص فایل‌های از قبل تبدیل شده به x265
- بررسی کیفیت ویدیو (حداقل 720p)
- استخراج اطلاعات کامل ویدیو (رزولوشن، کدک، مدت زمان، bitrate)

</div>

### 2. Intelligent Categorization | دسته‌بندی هوشمند

<div dir="rtl">

برنامه به صورت خودکار نوع محتوا را تشخیص می‌دهد:

- **فیلم**: فایل‌های بدون الگوی سریال
- **سریال**: تشخیص الگوهای S01E01، 1x01، Season 1 Episode 1
- **انیمه**: تشخیص کلمات کلیدی مثل "anime"، "انیمه"، "OVA"

</div>

### 3. Progress Tracking | ردیابی پیشرفت

<div dir="rtl">

نمایش اطلاعات زنده در حین تبدیل:

- درصد پیشرفت
- سرعت تبدیل (FPS)
- زمان سپری شده
- زمان باقیمانده (تخمینی)

برای پردازش دسته‌ای:
- پیشرفت کلی
- تعداد فایل‌های موفق
- تعداد فایل‌های ناموفق
- تعداد فایل‌های رد شده

</div>

### 4. Resource Management | مدیریت منابع

<div dir="rtl">

- نظارت بر استفاده از CPU و حافظه
- تعدیل خودکار تعداد threads بر اساس بار سیستم
- توقف موقت در صورت فشار زیاد به سیستم
- بهینه‌سازی خودکار برای جلوگیری از قفل شدن سیستم

</div>

### 5. Output Verification | بررسی خروجی

<div dir="rtl">

پس از تبدیل، فایل خروجی به صورت خودکار بررسی می‌شود:

- وجود جریان ویدیو
- صحت کدک (x265/HEVC)
- مقایسه مدت زمان با فایل ورودی
- حذف خودکار فایل‌های معیوب

</div>

### 6. Error Handling | مدیریت خطا

<div dir="rtl">

- پیام‌های خطای دقیق به زبان فارسی
- حذف خودکار فایل‌های ناقص
- ثبت تمام خطاها در فایل لاگ
- مقاومت در برابر وقفه (Ctrl+C)

</div>

### 7. Logging | لاگ‌گیری

<div dir="rtl">

تمام عملیات در فایل‌های لاگ ذخیره می‌شوند:

- `logs/conversion.log` - تمام رویدادها
- `logs/errors.log` - فقط خطاها

</div>

---

## Configuration | پیکربندی

<div dir="rtl">

برای تغییر تنظیمات، فایل `config.py` را ویرایش کنید:

</div>

```python
# تنظیمات کیفیت
QUALITY_PRESETS = {
    '720p': {'crf': 23, 'preset': 'medium'},
    '1080p': {'crf': 28, 'preset': 'slow'}
}

# تنظیمات صدا
AUDIO_CODEC = 'aac'
AUDIO_BITRATE = '192k'

# مدیریت منابع
MAX_CPU_PERCENT = 80
MIN_AVAILABLE_MEMORY_GB = 2
```

---

## Supported Formats | فرمت‌های پشتیبانی شده

<div dir="rtl">

**ورودی:**
- .mp4
- .mkv
- .avi
- .mov
- .flv
- .wmv
- .m4v
- .webm

**خروجی:**
- .mkv (با کدک x265/HEVC)

</div>

---

## Examples | مثال‌ها

### Example 1: Convert a Single Movie

```bash
python video_converter.py "The Matrix.mp4"
```

Output:
```
output/movies/The Matrix/The Matrix.mkv
```

### Example 2: Convert a TV Series

```bash
python video_converter.py "Breaking Bad S01E01.mkv" "Breaking Bad S01E02.mkv"
```

Output:
```
output/series/Breaking Bad/S01/Breaking Bad S01E01.mkv
output/series/Breaking Bad/S01/Breaking Bad S01E02.mkv
```

### Example 3: Batch Convert All Videos in a Folder

```bash
python video_converter.py /downloads/movies/
```

### Example 4: Custom Output Directory

```bash
python video_converter.py *.mp4 --output /media/converted
```

---

## Troubleshooting | رفع مشکلات

<div dir="rtl">

### خطا: "ffmpeg: command not found"

**راه‌حل:** FFmpeg را نصب کنید:
```bash
sudo apt install ffmpeg
```

### خطا: "فرمت فایل پشتیبانی نمی‌شود"

**راه‌حل:** فقط فرمت‌های معتبر ویدیو پشتیبانی می‌شوند. لیست فرمت‌های پشتیبانی شده را بررسی کنید.

### خطا: "کیفیت فیلم مناسب نیست"

**راه‌حل:** فقط ویدیوهای 720p و بالاتر قابل تبدیل هستند. ویدیوهای SD رد می‌شوند.

### خطا: "این فایل قبلاً به x265 تبدیل شده است"

**راه‌حل:** فایل از قبل فرمت x265 دارد و نیازی به تبدیل مجدد نیست.

### سیستم کند می‌شود

**راه‌حل:** برنامه به صورت خودکار منابع را مدیریت می‌کند، اما می‌توانید:
- از `--no-resource-check` برای غیرفعال کردن بررسی منابع استفاده کنید
- تنظیمات `MAX_CPU_PERCENT` را در `config.py` تغییر دهید

### مشاهده لاگ‌ها

```bash
cat logs/conversion.log    # تمام رویدادها
cat logs/errors.log        # فقط خطاها
```

</div>

---

## Performance Tips | نکات بهینه‌سازی

<div dir="rtl">

1. **سیستم‌های قدرتمند:** برای سیستم‌های قوی، می‌توانید preset را به `fast` یا `faster` تغییر دهید
2. **فضای دیسک:** اطمینان حاصل کنید فضای کافی برای فایل‌های خروجی دارید
3. **پردازش دسته‌ای:** برای تبدیل تعداد زیاد فایل، از پردازش دسته‌ای استفاده کنید
4. **حافظه:** برای ویدیوهای 4K، حداقل 8GB RAM توصیه می‌شود

</div>

---

## Advanced Usage | استفاده پیشرفته

### Custom Preset Example

<div dir="rtl">

برای تغییر preset به `faster` (سریع‌تر اما حجم بیشتر):

</div>

Edit `config.py`:
```python
QUALITY_PRESETS = {
    '720p': {'crf': 23, 'preset': 'faster'},
    '1080p': {'crf': 28, 'preset': 'faster'}
}
```

### Process Only Specific Seasons

```bash
python video_converter.py /path/to/series/*S01*.mkv
```

---

## License | مجوز

<div dir="rtl">

این نرم‌افزار رایگان و متن‌باز است. می‌توانید آن را برای هر منظوری استفاده، تغییر و توزیع کنید.

</div>

---

## Credits | سازندگان

<div dir="rtl">

- **FFmpeg** - ابزار قدرتمند پردازش ویدیو
- **tqdm** - کتابخانه نوار پیشرفت
- **psutil** - کتابخانه مانیتورینگ سیستم

</div>

---

## Support | پشتیبانی

<div dir="rtl">

برای گزارش مشکلات یا پیشنهادات، لاگ‌ها را بررسی کنید:

```bash
cat logs/errors.log
```

</div>

---

<div align="center" dir="rtl">

**ساخته شده با ❤️ برای تبدیل آسان ویدیوها به x265**

Made with ❤️ for easy video conversion to x265

</div>
