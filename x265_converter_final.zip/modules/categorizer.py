"""
File categorization module
ماژول دسته‌بندی فایل‌ها
"""
import os
import re
from config import OUTPUT_FOLDERS, SERIES_PATTERNS, ANIME_KEYWORDS
from modules.utils import sanitize_filename, extract_filename_without_ext, ensure_directory_exists
from modules.logger import logger


class Categorizer:
    """
    Categorize and organize video files
    دسته‌بندی و سازماندهی فایل‌های ویدیویی
    """
    
    @staticmethod
    def categorize_file(filepath, output_base_dir='output'):
        """
        Categorize file and determine output path
        دسته‌بندی فایل و تعیین مسیر خروجی
        
        Returns:
            dict with 'type', 'output_dir', 'output_file'
        """
        filename = os.path.basename(filepath)
        name_without_ext = extract_filename_without_ext(filepath)
        
        # Check if it's a series
        series_info = Categorizer._detect_series(name_without_ext)
        if series_info:
            return Categorizer._create_series_path(
                series_info, 
                filename, 
                output_base_dir
            )
        
        # Check if it's anime
        if Categorizer._is_anime(name_without_ext):
            return Categorizer._create_anime_path(
                name_without_ext,
                filename,
                output_base_dir
            )
        
        # Default to movie
        return Categorizer._create_movie_path(
            name_without_ext,
            filename,
            output_base_dir
        )
    
    @staticmethod
    def _detect_series(filename):
        """
        Detect if filename is a series and extract info
        تشخیص سریال بودن و استخراج اطلاعات
        
        Returns:
            dict with 'name', 'season', 'episode' or None
        """
        for pattern in SERIES_PATTERNS:
            match = re.search(pattern, filename, re.IGNORECASE)
            if match:
                season = int(match.group(1))
                episode = int(match.group(2))
                
                # Extract series name (everything before season/episode info)
                series_name = re.split(pattern, filename, flags=re.IGNORECASE)[0]
                series_name = series_name.strip('. -_')
                
                if not series_name:
                    series_name = f"Series_{season}"
                
                return {
                    'name': sanitize_filename(series_name),
                    'season': season,
                    'episode': episode
                }
        
        return None
    
    @staticmethod
    def _is_anime(filename):
        """
        Check if filename indicates anime
        بررسی انیمه بودن فایل
        """
        filename_lower = filename.lower()
        return any(keyword in filename_lower for keyword in ANIME_KEYWORDS)
    
    @staticmethod
    def _create_series_path(series_info, original_filename, base_dir):
        """
        Create output path for series
        ایجاد مسیر خروجی برای سریال
        """
        series_name = series_info['name']
        season = series_info['season']
        
        # Create path: output/series/[series_name]/S01/
        series_folder = OUTPUT_FOLDERS['series']
        season_folder = f"S{season:02d}"
        
        output_dir = os.path.join(
            base_dir,
            series_folder,
            series_name,
            season_folder
        )
        
        # Ensure directory exists
        ensure_directory_exists(output_dir)
        
        # Add x265 tag to filename and change extension to .mkv
        base_name = os.path.splitext(original_filename)[0]
        output_file = os.path.join(output_dir, f"{base_name}.x265.mkv")
        
        logger.debug(f"Categorized as series: {series_name} {season_folder}")
        
        return {
            'type': 'series',
            'name': series_name,
            'season': season,
            'output_dir': output_dir,
            'output_file': output_file
        }
        
        logger.debug(f"Categorized as series: {series_name} {season_folder}")
        
        return {
            'type': 'series',
            'name': series_name,
            'season': season,
            'output_dir': output_dir,
            'output_file': output_file
        }
    
    @staticmethod
    def _create_anime_path(anime_name, original_filename, base_dir):
        """
        Create output path for anime
        ایجاد مسیر خروجی برای انیمه
        """
        anime_name = sanitize_filename(anime_name)
        anime_folder = OUTPUT_FOLDERS['anime']
        
        output_dir = os.path.join(
            base_dir,
            anime_folder,
            anime_name
        )
        
        # Ensure directory exists
        ensure_directory_exists(output_dir)
        
        # Add x265 tag to filename and change extension to .mkv
        base_name = os.path.splitext(original_filename)[0]
        output_file = os.path.join(output_dir, f"{base_name}.x265.mkv")
        
        logger.debug(f"Categorized as anime: {anime_name}")
        
        return {
            'type': 'anime',
            'name': anime_name,
            'output_dir': output_dir,
            'output_file': output_file
        }
        
        logger.debug(f"Categorized as anime: {anime_name}")
        
        return {
            'type': 'anime',
            'name': anime_name,
            'output_dir': output_dir,
            'output_file': output_file
        }
    
    @staticmethod
    def _create_movie_path(movie_name, original_filename, base_dir):
        """
        Create output path for movie
        ایجاد مسیر خروجی برای فیلم
        """
        movie_name = sanitize_filename(movie_name)
        movie_folder = OUTPUT_FOLDERS['movie']
        
        output_dir = os.path.join(
            base_dir,
            movie_folder,
            movie_name
        )
        
        # Ensure directory exists
        ensure_directory_exists(output_dir)
        
        # Add x265 tag to filename and change extension to .mkv
        base_name = os.path.splitext(original_filename)[0]
        output_file = os.path.join(output_dir, f"{base_name}.x265.mkv")
        
        logger.debug(f"Categorized as movie: {movie_name}")
        
        return {
            'type': 'movie',
            'name': movie_name,
            'output_dir': output_dir,
            'output_file': output_file
        }
        
        logger.debug(f"Categorized as movie: {movie_name}")
        
        return {
            'type': 'movie',
            'name': movie_name,
            'output_dir': output_dir,
            'output_file': output_file
        }
