"""
Video converter module
ماژول تبدیل ویدیو
"""
import os
import subprocess
import signal
from config import (
    QUALITY_PRESETS, AUDIO_CODEC, AUDIO_BITRATE, 
    FFMPEG_BINARY, MESSAGES
)
from modules.logger import logger
from modules.progress import ProgressTracker
from modules.resource_manager import ResourceManager


class Converter:
    """
    Convert video files to x265
    تبدیل فایل‌های ویدیویی به x265
    """
    
    def __init__(self, input_file, output_file, metadata):
        """
        Initialize converter
        راه‌اندازی تبدیل‌کننده
        """
        self.input_file = input_file
        self.output_file = output_file
        self.metadata = metadata
        self.process = None
        self.interrupted = False
    
    def convert(self):
        """
        Convert video to x265
        تبدیل ویدیو به x265
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Determine quality preset
            quality = self.metadata.get('quality', '1080p')
            preset = self._get_preset(quality)
            
            # Build FFmpeg command
            cmd = self._build_ffmpeg_command(preset)
            
            logger.info(f"شروع تبدیل: {os.path.basename(self.input_file)}")
            logger.debug(f"Command: {' '.join(cmd)}")
            logger.info("🚀 اجرای دستور FFmpeg...")
            
            # Get recommended threads
            threads = ResourceManager.get_recommended_threads()
            logger.debug(f"Using {threads} threads")
            
            # Disable console logging BEFORE creating progress tracker
            logger.disable_console()
            
            # Set up progress tracker (this will show initial 0% bar)
            duration = self.metadata.get('duration', 0)
            filename = os.path.basename(self.input_file)
            quality = self.metadata.get('quality', 'Unknown')
            progress = ProgressTracker(duration=duration, filename=filename, quality=quality)
            
            # Run conversion
            success, line_count = self._run_conversion(cmd, progress)
            
            # Close progress
            progress.close()
            
            # Re-enable console logging after progress bar is closed
            logger.enable_console()
            logger.info(f"🏁 فرآیند تبدیل تکمیل شد. تعداد خطوط پردازش شده: {line_count}")
            
            if success:
                elapsed = progress.get_elapsed_time()
                logger.log_conversion_complete(self.output_file, elapsed)
                return True
            else:
                # Clean up incomplete file
                self._cleanup_incomplete_file()
                return False
                
        except Exception as e:
            logger.error(f"خطا در تبدیل: {str(e)}")
            self._cleanup_incomplete_file()
            return False
    
    def _get_preset(self, quality):
        """
        Get FFmpeg preset based on quality
        دریافت پیش‌تنظیم FFmpeg بر اساس کیفیت
        """
        if quality == '720p':
            return QUALITY_PRESETS['720p']
        else:
            # Use 1080p preset for 1080p and higher
            return QUALITY_PRESETS['1080p']
    
    def _build_ffmpeg_command(self, preset):
        """
        Build FFmpeg command
        ساخت دستور FFmpeg
        """
        cmd = [FFMPEG_BINARY, '-i', self.input_file]
        
        # Video encoding
        cmd.extend(['-c:v', 'libx265'])
        cmd.extend(['-crf', str(preset['crf'])])
        cmd.extend(['-preset', preset['preset']])
        
        # Downscale if needed
        height = self.metadata.get('height', 0)
        if height > 1080:
            cmd.extend(['-vf', 'scale=-2:1080'])
            logger.info("تبدیل به 1080p برای بهینه‌سازی حجم")
        
        # Audio encoding - copy ALL audio tracks
        audio_count = self.metadata.get('audio_streams', 0)
        if audio_count > 0:
            cmd.extend(['-map', '0:v:0'])  # Map video
            cmd.extend(['-map', '0:a'])  # Map ALL audio tracks
            logger.info(f"کپی {audio_count} track صدا")
        
        cmd.extend(['-c:a', AUDIO_CODEC])
        cmd.extend(['-b:a', AUDIO_BITRATE])
        
        # Use recommended threads
        threads = ResourceManager.get_recommended_threads()
        cmd.extend(['-threads', str(threads)])
        
        # Progress and overwrite
        cmd.extend(['-progress', 'pipe:1'])
        cmd.extend(['-y'])  # Overwrite output file
        
        # Output file
        cmd.append(self.output_file)
        
        return cmd
    
    def _run_conversion(self, cmd, progress):
        """
        Run FFmpeg conversion process
        اجرای فرآیند تبدیل FFmpeg
        """
        try:
            # Register signal handler for graceful shutdown
            signal.signal(signal.SIGINT, self._handle_interrupt)
            signal.signal(signal.SIGTERM, self._handle_interrupt)
            
            # Start process
            # (console logging already disabled before progress tracker creation)
            # Redirect stderr to stdout to capture everything in one stream
            # Use line buffering
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )
            
            # Reading output (console logging disabled)
            
            # Read stdout for progress (contains both logs and progress)
            line_count = 0
            for line in self.process.stdout:
                line_count += 1
                if line_count < 5:
                    logger.debug(f"FFmpeg Output [{line_count}]: {line.strip()}")
                
                if self.interrupted:
                    logger.warning("تبدیل متوقف شد")
                    self.process.terminate()
                    return False, line_count
                
                # Parse progress
                progress.parse_ffmpeg_output(line)
            
            # Don't re-enable console logging here - will be done after progress.close()
            
            # Wait for process to complete
            self.process.wait()
            
            # Check return code
            if self.process.returncode == 0:
                return True, line_count
            else:
                logger.error(f"FFmpeg خطا بازگشت: {self.process.returncode}")
                return False, line_count
                
        except Exception as e:
            logger.error(f"{MESSAGES['ffmpeg_error']}: {str(e)}")
            if self.process:
                self.process.terminate()
            return False, 0
    
    def _handle_interrupt(self, signum, frame):
        """
        Handle interrupt signal
        مدیریت سیگنال قطع
        """
        logger.warning(MESSAGES['interrupted'])
        self.interrupted = True
    
    def _cleanup_incomplete_file(self):
        """
        Delete incomplete output file
        حذف فایل خروجی ناقص
        """
        if os.path.exists(self.output_file):
            try:
                os.remove(self.output_file)
                logger.warning(MESSAGES['incomplete_conversion'])
            except OSError as e:
                logger.error(f"خطا در حذف فایل ناقص: {str(e)}")
