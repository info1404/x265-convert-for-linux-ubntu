"""
Progress display module for conversion
ماژول نمایش پیشرفت برای تبدیل
"""
import re
import time
import sys
import os
import shutil
from modules.utils import format_time

# ANSI Escape Codes
ESC = '\033'
CSI = ESC + '['
RESET = CSI + '0m'
BOLD = CSI + '1m'
HIDE_CURSOR = CSI + '?25l'
SHOW_CURSOR = CSI + '?25h'
CLEAR_LINE = CSI + '2K'  # Clear entire line
CLEAR_TO_END = CSI + 'K'  # Clear from cursor to end of line
MOVE_START = '\r'  # Move cursor to start of line

def rgb_to_ansi(r, g, b):
    """Convert RGB to ANSI 256 color code"""
    return f'{ESC}[38;2;{r};{g};{b}m'

def get_rainbow_color(percent):
    """
    Get RGB color based on percentage using smooth rainbow gradient
    """
    # Normalize to 0-1
    t = percent / 100.0
    
    # Rainbow: Red -> Orange -> Yellow -> Green -> Cyan -> Blue -> Purple
    if t < 0.15:   # Red to Orange
        r, g, b = 255, int(165 * (t/0.15)), 0
    elif t < 0.30: # Orange to Yellow
        r, g, b = 255, 165 + int(90 * ((t-0.15)/0.15)), 0
    elif t < 0.45: # Yellow to Green
        r, g, b = 255 - int(255 * ((t-0.30)/0.15)), 255, 0
    elif t < 0.60: # Green to Cyan
        r, g, b = 0, 255, int(255 * ((t-0.45)/0.15))
    elif t < 0.75: # Cyan to Blue
        r, g, b = 0, 255 - int(255 * ((t-0.60)/0.15)), 255
    else:          # Blue to Purple
        r, g, b = int(128 * ((t-0.75)/0.25)), 0, 255
        
    return rgb_to_ansi(r, g, b)

class ProgressTracker:
    """
    Track and display conversion progress manually
    ردیابی و نمایش پیشرفت تبدیل به صورت دستی
    """
    
    
    def __init__(self, total_frames=None, duration=None, filename="", quality=""):
        self.total_frames = total_frames
        self.duration = duration
        self.filename = filename
        self.quality = quality
        self.start_time = time.time()
        self.current_frame = 0
        self.current_time = 0
        self.fps = 0
        self.last_update = 0
        self.last_percent = -1
        
        # Use stderr for progress (so it doesn't mix with stdout pipes)
        # Check if it's a tty before using ANSI codes
        self.out = sys.stderr
        self.is_tty = self.out.isatty()
        
        if self.is_tty:
            # Hide cursor
            self.out.write(HIDE_CURSOR)
            self.out.flush()
            
            # Show initial empty bar
            self.update_progress(0)


    def parse_ffmpeg_output(self, line):

        # Extract frame number
        frame_match = re.search(r'frame=\s*(\d+)', line)
        if frame_match:
            self.current_frame = int(frame_match.group(1))
        
        # Extract fps
        fps_match = re.search(r'fps=\s*(\d+\.?\d*)', line)
        if fps_match:
            self.fps = float(fps_match.group(1))
        
        # Extract time (supports both 'time=' and 'out_time=')
        time_match = re.search(r'(?:out_)?time=(\d+):(\d+):(\d+\.?\d*)', line)
        if time_match:
            hours, minutes, seconds = time_match.groups()
            self.current_time = int(hours) * 3600 + int(minutes) * 60 + float(seconds)
            
            # Calculate percent if duration is known
            progress_percent = 0
            if self.duration and self.duration > 0:
                progress_percent = min((self.current_time / self.duration) * 100, 100)
            
            # Only update when integer percent changes (reduce update frequency)
            percent_int = int(progress_percent)
            if percent_int != self.last_percent:
                self.update_progress(progress_percent)

    def update_progress(self, percent):
        # Skip progress bar if not a tty
        if not self.is_tty:
            return
            
        percent_int = int(percent)
        elapsed = time.time() - self.start_time
        
        # Get terminal width
        try:
            # Subtract 1 to prevent auto-wrapping on some terminals
            columns = shutil.get_terminal_size().columns - 1
        except:
            columns = 79
            
        # Stats string (fixed part)
        # Stats string (fixed part)
        if percent > 0:
            eta = (elapsed / percent) * (100 - percent)
        else:
            eta = 0
            
        percent_color = get_rainbow_color(percent)
        
        # Format duration
        total_duration = format_time(self.duration) if self.duration else "??"
        
        stats_part = (
            f" {percent_color}{percent_int:3d}%{RESET} "
            f"│ ⚡ {self.fps:4.1f}fps "
            f"│ ⏱️  {format_time(elapsed)} "
            f"│ ⏳ {format_time(eta)}"
        )
        
        # Calculate lengths
        # We strip ANSI codes to get real length
        stats_len = len(re.sub(r'\x1b\[[0-9;]*m', '', stats_part))
        prefix_len = 2 # "⏳ "
        brackets_len = 2 # "[]"
        padding = 5 # Increased safety padding for emojis and wide characters
        
        # Priority 1: Stats must be shown
        # Priority 2: Bar must have minimum width
        min_bar_width = 10
        
        # Priority 3: Info (Filename) gets remaining space
        
        # Calculate used space by fixed elements
        # used = prefix + brackets + min_bar + stats + padding
        fixed_used_space = prefix_len + brackets_len + min_bar_width + stats_len + padding
        
        info_part = "" # Initialize info_part
        width = min_bar_width # Initialize width
        
        # Check if we have enough space for everything
        if columns < fixed_used_space:
            # Critical mode: Terminal too small
            # Hide info, reduce bar to minimum or 0 if needed
            available_width = columns - stats_len - prefix_len - brackets_len - padding
            width = max(0, available_width)
            info_part = ""
            # If width is 0, we might just print stats
        else:
            # We have space for Info
            available_for_info = columns - fixed_used_space
            
            # Construct Info Part
            base_info_str = f" | {self.quality} | {total_duration}"
            base_info_len = len(re.sub(r'\x1b\[[0-9;]*m', '', base_info_str)) # Calculate actual length
            
            # Calculate max filename length
            max_filename_len = available_for_info - base_info_len
            
            display_name = self.filename
            if max_filename_len < 5:
                # Very small space for filename
                if max_filename_len > 0:
                    display_name = display_name[:max_filename_len]
                else:
                    # No space for filename, maybe just show metadata or nothing
                    if available_for_info >= base_info_len:
                        display_name = "" # Show only metadata
                    else:
                        # Not enough space even for metadata
                        info_part = ""
                        # Re-calculate available width for bar to use up the empty info space
                        # available_width = columns - stats - prefix - padding
                        # (brackets removed since info is empty)
                        available_width = columns - stats_len - prefix_len - padding
                        width = max(min_bar_width, available_width)
                        
                        # Skip normal info construction
                        line = (
                            f"{MOVE_START}"
                            f"⏳ {BOLD}[{self._build_bar(width, percent)}]{RESET}"
                            f"{stats_part}"
                            f"{CLEAR_TO_END}"
                        )
                        self.out.write(line)
                        self.out.flush()
                        self.last_percent = percent_int
                        return

            elif len(display_name) > max_filename_len:
                display_name = display_name[:max_filename_len-3] + "..."
            
            if info_part != "": # This check is for the case where info_part was explicitly set to "" above
                pass # Already handled
            else:
                info_text = f"{display_name}{base_info_str}"
                info_part = f"{CSI}97m[{info_text}]{RESET} "
                
                # Recalculate info len
                info_len = len(re.sub(r'\x1b\[[0-9;]*m', '', info_part))
                
                # Calculate final available width for bar
                # available = columns - info - stats - prefix - padding
                # Note: brackets are inside info_part logic in original, but here we added them to info_text
                # Wait, original code had brackets outside info_text in info_part string: f"[{info_text}] "
                # My logic above: info_part = f"...[{info_text}] "
                # So info_len includes brackets and space.
                
                available_width = columns - info_len - stats_len - prefix_len - padding
                width = max(min_bar_width, available_width)
        
        # Build colored bar
        bar_str = self._build_bar(width, percent)
        
        # Construct the line
        # Move to start first, then clear to end, then write new content
        line = (
            f"{MOVE_START}"
            f"⏳ {info_part}{BOLD}[{bar_str}]{RESET}"
            f"{stats_part}"
            f"{CLEAR_TO_END}"
        )
        
        self.out.write(line)
        self.out.flush()
        self.last_percent = percent_int

    def _build_bar(self, width, percent):
        filled = int(width * percent / 100)
        bar_str = ""
        for i in range(width):
            if i < filled:
                bar_color = get_rainbow_color((i / width) * 100)
                bar_str += f"{bar_color}━{RESET}"
            else:
                bar_str += f"{CSI}90m─{RESET}"
        return bar_str
    
    def close(self):
        if not self.is_tty:
            return
            
        # Show 100%
        self.update_progress(100)
        self.out.write(f"\n{SHOW_CURSOR}")
        self.out.flush()
    
    def get_elapsed_time(self):
        return time.time() - self.start_time

class BatchProgressTracker:
    def __init__(self, total_files):
        self.total_files = total_files
        self.completed = 0
        self.failed = 0
        self.skipped = 0
        self.out = sys.stderr
        self.is_tty = self.out.isatty()
        
        if self.is_tty:
            self.out.write(f"\n📦 Batch Processing: {total_files} files\n")
            self.out.flush()
    
    def update(self, status='completed'):
        if status == 'completed': self.completed += 1
        elif status == 'failed': self.failed += 1
        elif status == 'skipped': self.skipped += 1
        
        if not self.is_tty:
            return
            
        total = self.completed + self.failed + self.skipped
        
        # Simple batch bar
        width = 30
        filled = int(width * total / self.total_files)
        bar = "█" * filled + "░" * (width - filled)
        
        self.out.write(f"{MOVE_START}📦 Batch: [{bar}] {total}/{self.total_files} (✓{self.completed} ✗{self.failed}){CLEAR_TO_END}")
        self.out.flush()
        
    def close(self):
        if self.is_tty:
            self.out.write("\n")
            self.out.flush()
        self.out.flush()
        
    def get_summary(self):
        return {
            'total': self.total_files,
            'completed': self.completed,
            'failed': self.failed,
            'skipped': self.skipped
        }
