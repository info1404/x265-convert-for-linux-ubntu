"""
Resource management module
ماژول مدیریت منابع سیستم
"""
import psutil
from config import MAX_CPU_PERCENT, MIN_AVAILABLE_MEMORY_GB
from modules.logger import logger


class ResourceManager:
    """
    Monitor and manage system resources
    نظارت و مدیریت منابع سیستم
    """
    
    @staticmethod
    def get_cpu_usage():
        """
        Get current CPU usage percentage
        دریافت درصد استفاده از CPU
        """
        return psutil.cpu_percent(interval=1)
    
    @staticmethod
    def get_available_memory_gb():
        """
        Get available memory in GB
        دریافت حافظه موجود به گیگابایت
        """
        mem = psutil.virtual_memory()
        return mem.available / (1024 ** 3)
    
    @staticmethod
    def get_memory_percent():
        """
        Get memory usage percentage
        دریافت درصد استفاده از حافظه
        """
        return psutil.virtual_memory().percent
    
    @staticmethod
    def is_system_overloaded():
        """
        Check if system is overloaded
        بررسی بار زیاد سیستم
        """
        cpu_usage = ResourceManager.get_cpu_usage()
        available_memory = ResourceManager.get_available_memory_gb()
        
        cpu_overload = cpu_usage > MAX_CPU_PERCENT
        memory_low = available_memory < MIN_AVAILABLE_MEMORY_GB
        
        if cpu_overload or memory_low:
            logger.warning(
                f"سیستم تحت فشار: CPU={cpu_usage:.1f}%, "
                f"حافظه موجود={available_memory:.2f}GB"
            )
            return True
        
        return False
    
    @staticmethod
    def get_recommended_threads():
        """
        Get recommended number of threads based on system load
        تعیین تعداد رشته‌های توصیه شده بر اساس بار سیستم
        """
        cpu_count = psutil.cpu_count(logical=True)
        cpu_usage = ResourceManager.get_cpu_usage()
        
        if cpu_usage > 80:
            # High load, use fewer threads
            return max(1, cpu_count // 4)
        elif cpu_usage > 60:
            # Medium load, use half threads
            return max(2, cpu_count // 2)
        else:
            # Low load, use most threads
            return max(2, cpu_count - 1)
    
    @staticmethod
    def get_system_stats():
        """
        Get comprehensive system statistics
        دریافت آمار کامل سیستم
        """
        cpu_percent = psutil.cpu_percent(interval=1)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        stats = {
            'cpu_percent': cpu_percent,
            'cpu_count': psutil.cpu_count(logical=True),
            'memory_total_gb': mem.total / (1024 ** 3),
            'memory_available_gb': mem.available / (1024 ** 3),
            'memory_percent': mem.percent,
            'disk_total_gb': disk.total / (1024 ** 3),
            'disk_free_gb': disk.free / (1024 ** 3),
            'disk_percent': disk.percent
        }
        
        return stats
    
    @staticmethod
    def log_system_stats():
        """
        Log current system statistics
        ثبت آمار فعلی سیستم
        """
        stats = ResourceManager.get_system_stats()
        
        logger.info(
            f"وضعیت سیستم - CPU: {stats['cpu_percent']:.1f}%, "
            f"حافظه: {stats['memory_percent']:.1f}% "
            f"({stats['memory_available_gb']:.1f}GB موجود), "
            f"دیسک: {stats['disk_percent']:.1f}% "
            f"({stats['disk_free_gb']:.1f}GB آزاد)"
        )
    
    @staticmethod
    def wait_for_resources():
        """
        Wait until system resources are available
        انتظار تا موجود شدن منابع سیستم
        """
        import time
        
        while ResourceManager.is_system_overloaded():
            logger.info("منتظر آزاد شدن منابع سیستم...")
            time.sleep(5)
        
        logger.info("منابع سیستم آماده است")
