"""
Utility functions for video converter
توابع کمکی برای تبدیل ویدیو
"""
import os
import re


def format_time(seconds):
    """
    Convert seconds to HH:MM:SS format
    تبدیل ثانیه به فرمت ساعت:دقیقه:ثانیه
    """
    if seconds is None or seconds < 0:
        return "00:00:00"
    
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def format_size(bytes_size):
    """
    Convert bytes to human-readable format
    تبدیل بایت به فرمت قابل خواندن
    """
    if bytes_size is None or bytes_size < 0:
        return "0 B"
    
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_size < 1024.0:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024.0
    
    return f"{bytes_size:.2f} PB"


def parse_duration(duration_str):
    """
    Parse FFmpeg duration string to seconds
    تبدیل رشته مدت زمان FFmpeg به ثانیه
    """
    if not duration_str:
        return 0
    
    # Format: HH:MM:SS.ms
    time_pattern = r'(\d+):(\d+):(\d+\.?\d*)'
    match = re.search(time_pattern, duration_str)
    
    if match:
        hours, minutes, seconds = match.groups()
        total_seconds = int(hours) * 3600 + int(minutes) * 60 + float(seconds)
        return total_seconds
    
    return 0


def get_file_size(filepath):
    """
    Get file size in bytes
    دریافت حجم فایل به بایت
    """
    try:
        return os.path.getsize(filepath)
    except OSError:
        return 0


def sanitize_filename(filename):
    """
    Remove invalid characters from filename
    حذف کاراکترهای نامعتبر از نام فایل
    """
    # Remove invalid characters
    invalid_chars = r'[<>:"/\\|?*]'
    sanitized = re.sub(invalid_chars, '_', filename)
    
    # Remove leading/trailing spaces and dots
    sanitized = sanitized.strip('. ')
    
    return sanitized


def extract_filename_without_ext(filepath):
    """
    Extract filename without extension
    استخراج نام فایل بدون پسوند
    """
    basename = os.path.basename(filepath)
    name_without_ext = os.path.splitext(basename)[0]
    return name_without_ext


def ensure_directory_exists(directory):
    """
    Create directory if it doesn't exist
    ایجاد پوشه در صورت عدم وجود
    """
    if not os.path.exists(directory):
        os.makedirs(directory, exist_ok=True)
        return True
    return False


def parse_resolution(width, height):
    """
    Determine quality level from resolution
    تعیین سطح کیفیت از رزولوشن
    """
    if height >= 2160:
        return '4K'
    elif height >= 1440:
        return '2K'
    elif height >= 1080:
        return '1080p'
    elif height >= 720:
        return '720p'
    elif height >= 480:
        return '480p'
    else:
        return 'SD'


def calculate_eta(elapsed_time, progress_percent):
    """
    Calculate estimated time of arrival
    محاسبه زمان تقریبی باقیمانده
    """
    if progress_percent <= 0:
        return None
    
    total_time = (elapsed_time / progress_percent) * 100
    remaining_time = total_time - elapsed_time
    
    return remaining_time if remaining_time > 0 else 0
