"""
Validation module for video files
ماژول اعتبارسنجی فایل‌های ویدیویی
"""
import os
import json
import subprocess
from config import SUPPORTED_FORMATS, MESSAGES, FFPROBE_BINARY
from modules.logger import logger
from modules.utils import parse_resolution


class ValidationResult:
    """
    Result of validation process
    نتیجه فرآیند اعتبارسنجی
    """
    
    def __init__(self, valid=True, error_message=None, metadata=None):
        self.valid = valid
        self.error_message = error_message
        self.metadata = metadata or {}
    
    def __bool__(self):
        return self.valid


class Validator:
    """
    Validator for video files
    اعتبارسنج فایل‌های ویدیویی
    """
    
    @staticmethod
    def validate_file(filepath):
        """
        Validate video file
        اعتبارسنجی فایل ویدیو
        
        Returns:
            ValidationResult with metadata
        """
        # Check if file exists
        if not os.path.exists(filepath):
            logger.log_validation_error(filepath, MESSAGES['file_not_found'])
            return ValidationResult(False, MESSAGES['file_not_found'])
        
        # Check file format
        _, ext = os.path.splitext(filepath)
        if ext.lower() not in SUPPORTED_FORMATS:
            logger.log_validation_error(filepath, MESSAGES['unsupported_format'])
            return ValidationResult(False, MESSAGES['unsupported_format'])
        
        # Extract metadata using ffprobe
        try:
            metadata = Validator._extract_metadata(filepath)
        except Exception as e:
            error_msg = f"خطا در استخراج اطلاعات: {str(e)}"
            logger.log_validation_error(filepath, error_msg)
            return ValidationResult(False, error_msg)
        
        # Check if file has video stream
        if not metadata.get('has_video'):
            logger.log_validation_error(filepath, MESSAGES['no_video_audio'])
            return ValidationResult(False, MESSAGES['no_video_audio'])
        
        # Check if already x265
        if metadata.get('codec_name') == 'hevc':
            logger.log_validation_error(filepath, MESSAGES['already_x265'])
            return ValidationResult(False, MESSAGES['already_x265'])
        
        # Check resolution
        height = metadata.get('height', 0)
        if height < 720:
            logger.log_validation_error(filepath, MESSAGES['low_quality'])
            return ValidationResult(False, MESSAGES['low_quality'])
        
        logger.info(f"✓ اعتبارسنجی موفق: {os.path.basename(filepath)}")
        logger.debug(f"Metadata: {metadata}")
        
        return ValidationResult(True, None, metadata)
    
    @staticmethod
    def _extract_metadata(filepath):
        """
        Extract video metadata using ffprobe
        استخراج اطلاعات ویدیو با ffprobe
        """
        cmd = [
            FFPROBE_BINARY,
            '-v', 'quiet',
            '-print_format', 'json',
            '-show_format',
            '-show_streams',
            filepath
        ]
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True,
                timeout=30  # Add timeout to prevent hanging
            )
            
            data = json.loads(result.stdout)
            
            # Find video stream
            video_stream = None
            audio_streams = []
            
            for stream in data.get('streams', []):
                if stream.get('codec_type') == 'video':
                    video_stream = stream
                elif stream.get('codec_type') == 'audio':
                    audio_streams.append(stream)
            
            if not video_stream:
                return {'has_video': False}
            
            # Extract video information
            width = int(video_stream.get('width', 0))
            height = int(video_stream.get('height', 0))
            codec_name = video_stream.get('codec_name', '')
            
            # Get duration
            duration = float(data.get('format', {}).get('duration', 0))
            
            # Get bitrate
            bit_rate = int(data.get('format', {}).get('bit_rate', 0))
            
            # Determine quality level
            quality = parse_resolution(width, height)
            
            # Select best audio track
            best_audio = None
            if audio_streams:
                # Prefer audio with most channels
                best_audio = max(audio_streams, key=lambda x: int(x.get('channels', 0)))
            
            metadata = {
                'has_video': True,
                'has_audio': len(audio_streams) > 0,
                'width': width,
                'height': height,
                'codec_name': codec_name,
                'quality': quality,
                'duration': duration,
                'bit_rate': bit_rate,
                'audio_streams': len(audio_streams),
                'best_audio_index': best_audio.get('index') if best_audio else None,
                'filepath': filepath
            }
            
            return metadata
            
        except subprocess.CalledProcessError as e:
            raise Exception(f"FFprobe error: {e.stderr}")
        except json.JSONDecodeError:
            raise Exception("Failed to parse ffprobe output")
        except Exception as e:
            raise Exception(f"Metadata extraction failed: {str(e)}")
