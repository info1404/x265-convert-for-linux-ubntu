"""
Output file verification module
ماژول بررسی فایل خروجی
"""
import os
import json
import subprocess
from config import FFPROBE_BINARY, MESSAGES
from modules.logger import logger


class Verifier:
    """
    Verify output file integrity
    بررسی سلامت فایل خروجی
    """
    
    @staticmethod
    def verify_output(output_file, expected_duration=None, input_file_size=None):
        """
        Verify output file is valid
        بررسی معتبر بودن فایل خروجی
        
        Returns:
            True if valid, False otherwise
        """
        # Check if file exists
        if not os.path.exists(output_file):
            logger.error(f"فایل خروجی یافت نشد: {output_file}")
            return False
        
        # Check file size
        file_size = os.path.getsize(output_file)
        if file_size < 1024:  # Less than 1KB
            logger.error(f"فایل خروجی بسیار کوچک است: {file_size} بایت")
            Verifier._move_to_incomplete(output_file)
            return False
            
        # Check if output is larger than input (if input size provided)
        if input_file_size and file_size > input_file_size:
            diff_mb = (file_size - input_file_size) / (1024 * 1024)
            logger.warning(f"\n{'!'*60}")
            logger.warning(f"⚠️  هشدار: حجم فایل خروجی بیشتر از ورودی شد! (+{diff_mb:.1f} MB)")
            logger.warning(f"   این فایل احتمالاً قبلاً فشرده شده بود (x265 یا bitrate پایین).")
            logger.warning(f"   پیشنهاد: فایل اصلی را نگه دارید یا تنظیمات کیفیت را تغییر دهید.")
            logger.warning(f"{'!'*60}\n")
        
        try:
            # Verify with ffprobe
            metadata = Verifier._probe_file(output_file)
            
            # Check for video stream
            if not metadata.get('has_video'):
                logger.error(f"فایل خروجی فاقد جریان ویدیو است: {output_file}")
                Verifier._move_to_incomplete(output_file)
                return False
            
            # Check codec is x265
            codec = metadata.get('codec_name', '')
            if codec != 'hevc':
                logger.warning(f"کدک فایل خروجی x265 نیست: {codec}")
            
            # Check duration
            if expected_duration:
                actual_duration = metadata.get('duration', 0)
                duration_diff = abs(actual_duration - expected_duration)
                
                # Allow 2% difference
                tolerance = expected_duration * 0.02
                
                if duration_diff > tolerance:
                    logger.warning(
                        f"اختلاف مدت زمان: انتظار {expected_duration:.2f}s, "
                        f"دریافت {actual_duration:.2f}s"
                    )
                    # Don't fail, just warn
            
            logger.log_verification_result(output_file, True)
            logger.info(f"✓ {MESSAGES['verification_passed']}: {os.path.basename(output_file)}")
            
            return True
            
        except Exception as e:
            logger.error(f"خطا در بررسی فایل: {str(e)}")
            Verifier._move_to_incomplete(output_file)
            return False
    
    @staticmethod
    def _probe_file(filepath):
        """
        Probe file with ffprobe
        بررسی فایل با ffprobe
        """
        cmd = [
            FFPROBE_BINARY,
            '-v', 'quiet',
            '-print_format', 'json',
            '-show_format',
            '-show_streams',
            filepath
        ]
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True,
                timeout=30
            )
            
            data = json.loads(result.stdout)
            
            # Find video stream
            video_stream = None
            for stream in data.get('streams', []):
                if stream.get('codec_type') == 'video':
                    video_stream = stream
                    break
            
            if not video_stream:
                return {'has_video': False}
            
            # Extract information
            codec_name = video_stream.get('codec_name', '')
            duration = float(data.get('format', {}).get('duration', 0))
            
            return {
                'has_video': True,
                'codec_name': codec_name,
                'duration': duration
            }
            
        except subprocess.TimeoutExpired:
            raise Exception("FFprobe timeout")
        except subprocess.CalledProcessError as e:
            raise Exception(f"FFprobe error: {e.stderr}")
        except json.JSONDecodeError:
            raise Exception("Failed to parse ffprobe output")
    
    @staticmethod
    def _move_to_incomplete(filepath):
        """
        Move invalid output file to _incomplete folder
        انتقال فایل نامعتبر به پوشه _incomplete
        """
        try:
            # Create _incomplete directory in the same folder as the file
            file_dir = os.path.dirname(filepath)
            incomplete_dir = os.path.join(file_dir, '_incomplete')
            os.makedirs(incomplete_dir, exist_ok=True)
            
            # Generate destination path
            filename = os.path.basename(filepath)
            dest_path = os.path.join(incomplete_dir, filename)
            
            # Handle duplicates
            counter = 1
            while os.path.exists(dest_path):
                name, ext = os.path.splitext(filename)
                dest_path = os.path.join(incomplete_dir, f"{name}_{counter}{ext}")
                counter += 1
            
            # Move file
            import shutil
            shutil.move(filepath, dest_path)
            logger.warning(f"⚠️  فایل نامعتبر منتقل شد به: _incomplete/{os.path.basename(dest_path)}")
            
        except Exception as e:
            logger.error(f"خطا در جابجایی فایل نامعتبر: {str(e)}")
            # If move fails, try to delete to avoid clutter
            try:
                os.remove(filepath)
            except:
                pass
