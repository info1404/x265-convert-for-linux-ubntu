# x265 Video Converter | تبدیل‌کننده ویدیو به x265

**نسخه 1.0 - ویرایش نهایی**

---

## 🎯 شروع سریع | Quick Start

### لینوکس / macOS

```bash
# 1. استخراج
unzip x265-video-converter-v1.0.zip
cd x265-video-converter-release

# 2. نصب خودکار
chmod +x install.sh
./install.sh

# 3. اجرا!
./start_watch.sh
```

### ویندوز

```cmd
# 1. استخراج ZIP
# 2. نصب وابستگی‌ها
pip install -r requirements.txt

# 3. اجرا!
python auto_watch.py
```

---

## 📦 دو حالت کاری

### 🔍 حالت 1: نظارت خودکار (توصیه می‌شود!)

```bash
./start_watch.sh
```

**سپس فایل‌ها را در پوشه `input` بگذارید - خودکار تبدیل می‌شوند!**

```
input/              ← فایل‌ها را اینجا بگذارید
├── _processed/     ← فایل‌های موفق
└── _failed/        ← فایل‌های ناموفق

output/             ← فایل‌های تبدیل شده (x265)
├── movies/
├── series/
└── anime/
```

### ⚡ حالت 2: دستی

```bash
python3 video_converter.py video.mp4
python3 video_converter.py /path/to/videos/
```

---

## ✨ ویژگی‌های جدید

### 1. نوار پیشرفت کامل
```
⚡ تبدیل | سرعت: 45.2 fps | گذشته: 00:05:23 | باقی‌مانده: 00:12:45
  75%|████████████████████▌     | [00:05:23<00:12:45]
```

### 2. نام فایل با علامت x265
```
The Matrix.x265.mkv
Breaking Bad S01E01.x265.mkv
Naruto Episode 01.x265.mkv
```

---

## 📋 پیش‌نیازها

### حتماً نصب کنید:

1. **Python 3.8+**
   ```bash
   python3 --version
   ```

2. **FFmpeg**
   ```bash
   # لینوکس
   sudo apt install ffmpeg
   
   # macOS
   brew install ffmpeg
   
   # ویندوز: دانلود از ffmpeg.org
   ```

3. **کتابخانه‌های Python**
   ```bash
   pip install -r requirements.txt
   ```

---

## 🎯 مثال عملی

### Terminal 1: شروع برنامه
```bash
$ ./start_watch.sh
🔍 حالت نظارت خودکار فعال شد
📌 فایل‌ها را در input/ بگذارید
```

### Terminal 2: اضافه کردن فایل
```bash
$ cp ~/Downloads/movie.mp4 input/
```

### Terminal 1: تبدیل خودکار!
```
🔔 1 فایل جدید یافت شد!
🆕 فایل جدید شناسایی شد: movie.mp4

⚡ تبدیل | سرعت: 45.2 fps | گذشته: 00:05:23 | باقی‌مانده: 00:12:45
  75%|████████████████████▌     | [00:05:23<00:12:45]

✅ تبدیل موفق
✅ فایل منتقل شد به: _processed/movie.mp4
📁 خروجی: output/movies/movie/movie.x265.mkv
```

---

## 📖 مستندات

| فایل | توضیحات |
|------|---------|
| **README.md** | راهنمای کامل برنامه |
| **AUTO_WATCH.md** | راهنمای حالت نظارت خودکار |
| **INSTALLATION.md** | نصب در سیستم‌های مختلف |
| **QUICK_REFERENCE.md** | مرجع سریع دستورات |

---

## 🌍 سازگاری

| سیستم | نصب | اجرا |
|-------|-----|------|
| 🐧 **Linux** | `./install.sh` | `./start_watch.sh` |
| 🪟 **Windows** | `pip install -r requirements.txt` | `python auto_watch.py` |
| 🍎 **macOS** | `./install.sh` | `./start_watch.sh` |

---

## 🎁 ویژگی‌های کلیدی

✅ **تبدیل هوشمند** - 720p, 1080p, 4K  
✅ **نوار پیشرفت زنده** - سرعت، زمان، درصد  
✅ **نام‌گذاری با x265** - فایل.x265.mkv  
✅ **حالت نظارت خودکار** - فایل بگذار، فراموش کن!  
✅ **دسته‌بندی هوشمند** - فیلم/سریال/انیمه  
✅ **مدیریت منابع** - بدون کند شدن سیستم  
✅ **رابط فارسی** - کاملاً فارسی  
✅ **لاگ جامع** - ثبت همه عملیات  

---

## ⚠️ نکات مهم

1. **FFmpeg ضروری است** - اول نصب کنید
2. **فضای دیسک** - 2x حجم فایل اصلی
3. **کیفیت حداقل 720p** - پایین‌تر رد می‌شود
4. **پردازش خودکار** - فایل‌های معیوب به `_failed` منتقل می‌شوند

---

## 🚀 شروع در 30 ثانیه!

```bash
# لینوکس
./install.sh && ./start_watch.sh

# ویندوز
pip install -r requirements.txt && python auto_watch.py
```

**سپس فایل‌ها را در `input/` بگذارید!** 🎉

---

<div align="center">

**🎬 ساخته شده با ❤️ برای تبدیل آسان ویدیوها به x265**

**نسخه 1.0 | 2025**

</div>
