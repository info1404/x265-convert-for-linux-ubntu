#!/usr/bin/env python3
"""
Auto Watch Mode for x265 Video Converter
حالت نظارت خودکار برای تبدیل‌کننده ویدیو

Automatically watches a folder and converts any new video files
به طور خودکار پوشه را نظارت می‌کند و ویدیوهای جدید را تبدیل می‌کند
"""
import os
import sys
import time
import shutil
import argparse
from pathlib import Path
from modules.logger import logger
from video_converter import VideoConverter, collect_video_files


class WatchFolder:
    """
    Watch folder for new video files and auto-convert
    نظارت بر پوشه و تبدیل خودکار ویدیوهای جدید
    """
    
    def __init__(self, watch_dir='input', output_dir='output', check_interval=5):
        """
        Initialize watch folder
        راه‌اندازی پوشه نظارت
        """
        self.watch_dir = os.path.abspath(watch_dir)
        self.output_dir = output_dir
        self.check_interval = check_interval
        self.processed_files = set()
        self.processing_files = set()
        
        # Create watch directory
        os.makedirs(self.watch_dir, exist_ok=True)
        
        # Initialize converter
        self.converter = VideoConverter(output_dir=output_dir, verify=True)
        
        logger.info(f"📁 پوشه نظارت شده: {self.watch_dir}")
        logger.info(f"📂 پوشه خروجی: {self.output_dir}")
    
    def get_video_files(self):
        """
        Get all video files in watch directory
        دریافت تمام فایل‌های ویدیو در پوشه نظارت
        """
        video_files = collect_video_files([self.watch_dir])
        
        # Filter out files we've already processed or are processing
        new_files = [
            f for f in video_files 
            if f not in self.processed_files and f not in self.processing_files
        ]
        
        return new_files
    
    def is_file_ready(self, filepath, wait_time=2):
        """
        Check if file is completely copied (not being written)
        بررسی کامل بودن کپی فایل
        """
        try:
            initial_size = os.path.getsize(filepath)
            time.sleep(wait_time)
            final_size = os.path.getsize(filepath)
            
            # If size hasn't changed, file is ready
            return initial_size == final_size
        except OSError:
            return False
    
    def process_file(self, filepath):
        """
        Process a single video file
        پردازش یک فایل ویدیو
        """
        filename = os.path.basename(filepath)
        max_retries = 2
        
        logger.info(f"\n{'='*60}")
        logger.info(f"🆕 فایل جدید شناسایی شد: {filename}")
        logger.info(f"{'='*60}")
        
        # Mark as processing
        self.processing_files.add(filepath)
        
        try:
            # Wait for file to be completely copied
            logger.info("⏳ در انتظار کامل شدن کپی فایل...")
            if not self.is_file_ready(filepath, wait_time=3):
                logger.warning("⚠️  فایل هنوز در حال کپی است، صبر می‌کنیم...")
                time.sleep(5)
            
            # Retry loop
            success = False
            for attempt in range(1, max_retries + 1):
                if attempt > 1:
                    logger.warning(f"🔄 تلاش مجدد {attempt}/{max_retries} برای {filename}...")
                
                # Convert file
                success = self.converter.convert_single_file(filepath)
                
                if success:
                    break
                else:
                    logger.error(f"❌ تلاش {attempt} ناموفق بود.")
                    if attempt < max_retries:
                        time.sleep(2)  # Wait a bit before retry
            
            if success:
                # Move processed file to 'processed' folder
                processed_dir = os.path.join(self.watch_dir, '_processed')
                os.makedirs(processed_dir, exist_ok=True)
                
                dest_path = os.path.join(processed_dir, filename)
                
                # Handle duplicate names
                counter = 1
                while os.path.exists(dest_path):
                    name, ext = os.path.splitext(filename)
                    dest_path = os.path.join(processed_dir, f"{name}_{counter}{ext}")
                    counter += 1
                
                shutil.move(filepath, dest_path)
                logger.info(f"✅ فایل اصلی منتقل شد به: _processed/{os.path.basename(dest_path)}")
                
                # Mark as processed
                self.processed_files.add(filepath)
            else:
                # Move failed file to 'failed' folder
                failed_dir = os.path.join(self.watch_dir, '_failed')
                os.makedirs(failed_dir, exist_ok=True)
                
                dest_path = os.path.join(failed_dir, filename)
                counter = 1
                while os.path.exists(dest_path):
                    name, ext = os.path.splitext(filename)
                    dest_path = os.path.join(failed_dir, f"{name}_{counter}{ext}")
                    counter += 1
                
                shutil.move(filepath, dest_path)
                logger.error(f"❌ فایل پس از {max_retries} تلاش ناموفق منتقل شد به: _failed/{os.path.basename(dest_path)}")
                
        except Exception as e:
            logger.error(f"خطا در پردازش {filename}: {str(e)}")
        finally:
            # Remove from processing set
            self.processing_files.discard(filepath)
    
    def check_incomplete_and_retry(self):
        """
        Check for incomplete files and retry corresponding failed files
        بررسی فایل‌های ناقص و تلاش مجدد برای فایل‌های ناموفق مرتبط
        """
        incomplete_dir = os.path.join(self.output_dir, '_incomplete')
        failed_dir = os.path.join(self.watch_dir, '_failed')
        
        if not os.path.exists(incomplete_dir) or not os.path.exists(failed_dir):
            return
            
        logger.info("🔍 بررسی فایل‌های ناقص برای تلاش مجدد...")
        
        # Get list of incomplete files
        try:
            incomplete_files = os.listdir(incomplete_dir)
        except OSError:
            return
            
        count = 0
        for incomplete_file in incomplete_files:
            # Extract original name (remove .x265.mkv)
            # Assuming format: name.x265.mkv or name_1.x265.mkv
            base_name = incomplete_file.replace('.x265.mkv', '')
            
            # Handle duplicates suffix in incomplete file if present (e.g. name_1)
            # This is a simple heuristic, might need adjustment if naming scheme changes
            
            # Search for this file in _failed
            # We need to find a file in _failed that matches this base name
            # Since extensions might differ (input mp4 vs output mkv), we check base names
            
            for failed_file in os.listdir(failed_dir):
                failed_base = os.path.splitext(failed_file)[0]
                
                # Check if base names match (ignoring potential _1 suffix in incomplete)
                if base_name.startswith(failed_base):
                    failed_path = os.path.join(failed_dir, failed_file)
                    input_path = os.path.join(self.watch_dir, failed_file)
                    
                    if not os.path.exists(input_path):
                        try:
                            shutil.move(failed_path, input_path)
                            logger.info(f"♻️  بازگردانی فایل برای تلاش مجدد: {failed_file}")
                            count += 1
                        except OSError as e:
                            logger.error(f"خطا در بازگردانی فایل {failed_file}: {e}")
                    break
        
        if count > 0:
            logger.info(f"✅ {count} فایل برای پردازش مجدد به صف اضافه شد.")

    def watch(self):
        """
        Main watch loop
        حلقه اصلی نظارت
        """
        logger.info(f"\n{'='*60}")
        logger.info("🔍 حالت نظارت خودکار فعال شد")
        logger.info(f"{'='*60}")
        logger.info(f"📌 فایل‌های ویدیو را در این پوشه قرار دهید:")
        logger.info(f"   {self.watch_dir}")
        logger.info(f"\n💡 برنامه هر {self.check_interval} ثانیه پوشه را بررسی می‌کند")
        logger.info(f"⏸️  برای توقف: Ctrl+C\n")
        
        # Check for incomplete files on startup
        self.check_incomplete_and_retry()
        
        try:
            while True:
                # Check for new files
                # logger.debug("Scanning for files...")
                new_files = self.get_video_files()
                
                if new_files:
                    logger.info(f"🔔 {len(new_files)} فایل جدید یافت شد!")
                    logger.debug(f"Files: {new_files}")
                    
                    for filepath in new_files:
                        self.process_file(filepath)
                else:
                    # logger.debug("No new files found.")
                    pass
                
                # Wait before next check
                time.sleep(self.check_interval)
                
        except KeyboardInterrupt:
            logger.info("\n\n🛑 حالت نظارت متوقف شد")
            logger.info(f"📊 تعداد فایل‌های پردازش شده: {len(self.processed_files)}")


def main():
    """
    Main entry point for watch mode
    نقطه ورود اصلی برای حالت نظارت
    """
    parser = argparse.ArgumentParser(
        description='حالت نظارت خودکار - فایل‌ها را در پوشه input قرار دهید',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
مثال‌ها:
  %(prog)s                                    # نظارت پوشه input (پیش‌فرض)
  %(prog)s --watch /custom/watch/folder      # نظارت پوشه سفارشی
  %(prog)s --interval 10                     # بررسی هر 10 ثانیه
        """
    )
    
    parser.add_argument(
        '-w', '--watch',
        default='input',
        help='پوشه‌ای که نظارت می‌شود (پیش‌فرض: input)'
    )
    
    parser.add_argument(
        '-o', '--output',
        default='output',
        help='پوشه خروجی (پیش‌فرض: output)'
    )
    
    parser.add_argument(
        '-i', '--interval',
        type=int,
        default=5,
        help='زمان بررسی به ثانیه (پیش‌فرض: 5)'
    )
    
    args = parser.parse_args()
    
    # Create and start watcher
    watcher = WatchFolder(
        watch_dir=args.watch,
        output_dir=args.output,
        check_interval=args.interval
    )
    
    watcher.watch()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nبرنامه توسط کاربر متوقف شد")
        sys.exit(0)
    except Exception as e:
        logger.critical(f"خطای غیرمنتظره: {str(e)}")
        sys.exit(1)
