import os
import glob
import sys

def diagnose():
    input_dir = os.path.abspath('input')
    print(f"Diagnosing directory: {input_dir}")
    
    if not os.path.exists(input_dir):
        print("❌ Input directory does not exist!")
        return
        
    print("✅ Input directory exists.")
    print(f"Permissions: {oct(os.stat(input_dir).st_mode)[-3:]}")
    
    print("\nListing all files in input directory:")
    files = os.listdir(input_dir)
    if not files:
        print("⚠️  Directory is empty.")
    
    for f in files:
        full_path = os.path.join(input_dir, f)
        is_file = os.path.isfile(full_path)
        size = os.path.getsize(full_path) if is_file else 0
        print(f"  - {f} ({'File' if is_file else 'Dir'}, Size: {size} bytes)")
        
    print("\nChecking for supported video files (recursive):")
    supported_formats = ['.mp4', '.mkv', '.avi', '.mov', '.flv', '.wmv', '.m4v', '.webm']
    
    video_files = []
    for root, dirs, files in os.walk(input_dir):
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in supported_formats:
                video_files.append(os.path.join(root, file))
                
    if video_files:
        print(f"✅ Found {len(video_files)} video files:")
        for v in video_files:
            print(f"  - {v}")
    else:
        print("❌ No supported video files found recursively.")

if __name__ == "__main__":
    diagnose()
