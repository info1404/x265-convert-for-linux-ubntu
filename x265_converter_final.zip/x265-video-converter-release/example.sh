#!/bin/bash
# Example usage script for x265 video converter
# اسکریپت نمونه برای استفاده از تبدیل‌کننده ویدیو

echo "=== x265 Video Converter Examples ==="
echo ""

# Example 1: Convert a single file
echo "Example 1: Convert a single file"
echo "Command: python video_converter.py video.mp4"
echo ""

# Example 2: Convert multiple files
echo "Example 2: Convert multiple files"
echo "Command: python video_converter.py video1.mp4 video2.mkv video3.avi"
echo ""

# Example 3: Convert all MP4 files in current directory
echo "Example 3: Convert all MP4 files in current directory"
echo "Command: python video_converter.py *.mp4"
echo ""

# Example 4: Convert all videos in a directory
echo "Example 4: Convert all videos in a directory"
echo "Command: python video_converter.py /path/to/videos/"
echo ""

# Example 5: Custom output directory
echo "Example 5: Custom output directory"
echo "Command: python video_converter.py video.mp4 --output /my/custom/output"
echo ""

# Example 6: Verbose mode
echo "Example 6: Verbose mode with debug information"
echo "Command: python video_converter.py video.mp4 --verbose"
echo ""

# Example 7: No verification
echo "Example 7: Convert without output verification"
echo "Command: python video_converter.py video.mp4 --no-verify"
echo ""

# Example 8: Process series
echo "Example 8: Process TV series files"
echo "Command: python video_converter.py 'Breaking Bad S01E'*.mkv"
echo ""

echo "=== For help, run: python video_converter.py --help ==="
