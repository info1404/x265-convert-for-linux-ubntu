"""
Logging module for video converter
ماژول ثبت رویدادها برای تبدیل ویدیو
"""
import logging
import os
import sys
from datetime import datetime
from config import LOG_FILE, ERROR_LOG_FILE, LOG_FORMAT, DATE_FORMAT


class Logger:
    """
    Custom logger for video conversion operations
    ثبت رویدادهای عملیات تبدیل ویدیو
    """
    
    def __init__(self, name='VideoConverter', log_dir='logs'):
        """
        Initialize logger
        راه‌اندازی ثبت رویدادها
        """
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)
        
        # Create logs directory
        if not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)
        
        # File handler for all logs
        log_path = os.path.join(log_dir, LOG_FILE)
        file_handler = logging.FileHandler(log_path, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(logging.Formatter(LOG_FORMAT, DATE_FORMAT))
        
        # File handler for errors only
        error_path = os.path.join(log_dir, ERROR_LOG_FILE)
        error_handler = logging.FileHandler(error_path, encoding='utf-8')
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(logging.Formatter(LOG_FORMAT, DATE_FORMAT))
        
        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
        
        # Store for compatibility
        self.console_handler = console_handler
        
        # Add handlers
        self.logger.addHandler(file_handler)
        self.logger.addHandler(error_handler)
        self.logger.addHandler(console_handler)
    
    def debug(self, message):
        """Log debug message"""
        self.logger.debug(message)
    
    def info(self, message):
        """Log info message"""
        self.logger.info(message)
    
    def warning(self, message):
        """Log warning message"""
        self.logger.warning(message)
    
    def error(self, message):
        """Log error message"""
        self.logger.error(message)
    
    def critical(self, message):
        """Log critical message"""
        self.logger.critical(message)
    
    def log_conversion_start(self, input_file, output_file):
        """Log conversion start"""
        self.info(f"شروع تبدیل: {input_file} -> {output_file}")
        self.debug(f"Conversion started: {input_file} -> {output_file}")
    
    def log_conversion_complete(self, output_file, elapsed_time):
        """Log conversion completion"""
        self.info(f"تبدیل کامل شد: {output_file} (زمان: {elapsed_time:.2f}s)")
        self.debug(f"Conversion completed: {output_file} (time: {elapsed_time:.2f}s)")
    
    def log_conversion_error(self, input_file, error_message):
        """Log conversion error"""
        self.error(f"خطا در تبدیل {input_file}: {error_message}")
    
    def log_validation_error(self, input_file, reason):
        """Log validation error"""
        self.warning(f"اعتبارسنجی ناموفق: {input_file} - {reason}")
    
    def log_verification_result(self, output_file, passed):
        """Log verification result"""
        status = "سالم" if passed else "دچار مشکل"
        self.info(f"بررسی فایل خروجی {output_file}: {status}")


# Global logger instance
logger = Logger()
