"""
Progress display module for conversion
ماژول نمایش پیشرفت برای تبدیل
"""
import re
import time
import sys
import os
import shutil
from modules.utils import format_time

# ANSI Escape Codes
ESC = '\033'
CSI = ESC + '['
RESET = CSI + '0m'
BOLD = CSI + '1m'
HIDE_CURSOR = CSI + '?25l'
SHOW_CURSOR = CSI + '?25h'
CLEAR_LINE = CSI + '2K'
MOVE_START = '\r'

def rgb_to_ansi(r, g, b):
    """Convert RGB to ANSI 256 color code"""
    return f'{ESC}[38;2;{r};{g};{b}m'

def get_rainbow_color(percent):
    """
    Get RGB color based on percentage using smooth rainbow gradient
    """
    # Normalize to 0-1
    t = percent / 100.0
    
    # Rainbow: Red -> Orange -> Yellow -> Green -> Cyan -> Blue -> Purple
    if t < 0.15:   # Red to Orange
        r, g, b = 255, int(165 * (t/0.15)), 0
    elif t < 0.30: # Orange to Yellow
        r, g, b = 255, 165 + int(90 * ((t-0.15)/0.15)), 0
    elif t < 0.45: # Yellow to Green
        r, g, b = 255 - int(255 * ((t-0.30)/0.15)), 255, 0
    elif t < 0.60: # Green to Cyan
        r, g, b = 0, 255, int(255 * ((t-0.45)/0.15))
    elif t < 0.75: # Cyan to Blue
        r, g, b = 0, 255 - int(255 * ((t-0.60)/0.15)), 255
    else:          # Blue to Purple
        r, g, b = int(128 * ((t-0.75)/0.25)), 0, 255
        
    return rgb_to_ansi(r, g, b)

class ProgressTracker:
    """
    Track and display conversion progress manually
    ردیابی و نمایش پیشرفت تبدیل به صورت دستی
    """
    
    def __init__(self, total_frames=None, duration=None, filename="", quality=""):
        self.total_frames = total_frames
        self.duration = duration
        self.filename = filename
        self.quality = quality
        self.start_time = time.time()
        self.current_frame = 0
        self.current_time = 0
        self.fps = 0
        self.last_update = 0
        self.last_percent = -1
        
        # Use stdout for progress
        self.out = sys.stdout
        
        # Hide cursor
        self.out.write(HIDE_CURSOR)
        self.out.flush()
        
        # Show initial empty bar
        self.update_progress(0)

    def parse_ffmpeg_output(self, line):
        # Debug: log line to file
        with open('ffmpeg_debug.txt', 'a', encoding='utf-8') as f:
            f.write(line)

        # Extract frame number
        frame_match = re.search(r'frame=\s*(\d+)', line)
        if frame_match:
            self.current_frame = int(frame_match.group(1))
        
        # Extract fps
        fps_match = re.search(r'fps=\s*(\d+\.?\d*)', line)
        if fps_match:
            self.fps = float(fps_match.group(1))
        
        # Extract time (supports both 'time=' and 'out_time=')
        time_match = re.search(r'(?:out_)?time=(\d+):(\d+):(\d+\.?\d*)', line)
        if time_match:
            hours, minutes, seconds = time_match.groups()
            self.current_time = int(hours) * 3600 + int(minutes) * 60 + float(seconds)
            
            # Calculate percent if duration is known
            progress_percent = 0
            if self.duration and self.duration > 0:
                progress_percent = min((self.current_time / self.duration) * 100, 100)
            
            # Update every 0.5 seconds for smoothness
            current = time.time()
            if current - self.last_update >= 0.5:
                self.update_progress(progress_percent)
                self.last_update = current

    def update_progress(self, percent):
        percent_int = int(percent)
        elapsed = time.time() - self.start_time
        
        # Get terminal width
        try:
            columns = shutil.get_terminal_size().columns
        except:
            columns = 80
            
        # Stats string (fixed part)
        if percent > 0:
            eta = (elapsed / percent) * (100 - percent)
        else:
            eta = 0
            
        percent_color = get_rainbow_color(percent)
        
        # Shorten filename if needed
        display_name = self.filename
        if len(display_name) > 20:
            display_name = display_name[:17] + "..."
            
        # Format duration
        total_duration = format_time(self.duration) if self.duration else "??"
        
        # Info part: [Movie.mkv | 1080p | 01:30:00]
        info_text = f"{display_name} | {self.quality} | {total_duration}"
        info_part = f"{CSI}97m[{info_text}]{RESET} "
        
        stats_part = (
            f" {percent_color}{percent_int:3d}%{RESET} "
            f"│ ⚡ {self.fps:4.1f}fps "
            f"│ ⏱️  {format_time(elapsed)} "
            f"│ ⏳ {format_time(eta)}"
        )
        
        # Calculate available width for bar
        # Format: ⏳ INFO [BAR] STATS
        # We need to strip ANSI codes to get real length
        info_len = len(re.sub(r'\x1b\[[0-9;]*m', '', info_part))
        stats_len = len(re.sub(r'\x1b\[[0-9;]*m', '', stats_part))
        prefix_len = 2 # "⏳ "
        brackets_len = 2 # "[]"
        
        available_width = columns - info_len - stats_len - prefix_len - brackets_len - 2
        
        # Minimum bar width
        width = max(10, available_width)
        
        # If terminal is too small, truncate stats or info
        if width < 10:
            width = 10
        
        filled = int(width * percent / 100)
        
        # Build colored bar
        bar_str = ""
        for i in range(width):
            if i < filled:
                # Color varies across the bar
                bar_color = get_rainbow_color((i / width) * 100)
                bar_str += f"{bar_color}━{RESET}"
            else:
                bar_str += f"{CSI}90m─{RESET}"
        
        # Construct the line
        # Use \r to move to start, then content, then Clear to End of Line (K)
        line = (
            f"{MOVE_START}"
            f"⏳ {info_part}{BOLD}[{bar_str}]{RESET}"
            f"{stats_part}"
            f"{CSI}K"
        )
        
        self.out.write(line)
        self.out.flush()
        self.last_percent = percent_int
    
    def close(self):
        # Show 100%
        self.update_progress(100)
        self.out.write(f"\n{SHOW_CURSOR}")
        self.out.flush()
    
    def get_elapsed_time(self):
        return time.time() - self.start_time

class BatchProgressTracker:
    def __init__(self, total_files):
        self.total_files = total_files
        self.completed = 0
        self.failed = 0
        self.skipped = 0
        self.out = sys.stderr
        self.out.write(f"\n📦 Batch Processing: {total_files} files\n")
        self.out.flush()
    
    def update(self, status='completed'):
        if status == 'completed': self.completed += 1
        elif status == 'failed': self.failed += 1
        elif status == 'skipped': self.skipped += 1
        
        total = self.completed + self.failed + self.skipped
        
        # Simple batch bar
        width = 30
        filled = int(width * total / self.total_files)
        bar = "█" * filled + "░" * (width - filled)
        
        self.out.write(f"{CLEAR_LINE}{MOVE_START}📦 Batch: [{bar}] {total}/{self.total_files} (✓{self.completed} ✗{self.failed})")
        self.out.flush()
        
    def close(self):
        self.out.write("\n")
        self.out.flush()
        
    def get_summary(self):
        return {
            'total': self.total_files,
            'completed': self.completed,
            'failed': self.failed,
            'skipped': self.skipped
        }
