"""
Progress display module for conversion
ماژول نمایش پیشرفت برای تبدیل
"""
import re
import time
import sys
from modules.utils import format_time


def get_progress_color(percent):
    """Get color based on progress percentage"""
    if percent < 10:
        return '\033[91m'  # Red
    elif percent < 20:
        return '\033[93m'  # Yellow
    elif percent < 30:
        return '\033[94m'  # Blue
    elif percent < 40:
        return '\033[95m'  # Magenta
    elif percent < 50:
        return '\033[96m'  # Cyan
    elif percent < 60:
        return '\033[92m'  # Green
    elif percent < 70:
        return '\033[97m'  # White
    elif percent < 80:
        return '\033[94m'  # Blue
    elif percent < 90:
        return '\033[95m'  # Magenta
    else:
        return '\033[92m'  # Green


class ProgressTracker:
    """
    Track and display conversion progress
    ردیابی و نمایش پیشرفت تبدیل
    """
    
    def __init__(self, total_frames=None, duration=None):
        """
        Initialize progress tracker
        راه‌اندازی ردیاب پیشرفت
        """
        self.total_frames = total_frames
        self.duration = duration
        self.start_time = time.time()
        self.current_frame = 0
        self.current_time = 0
        self.fps = 0
        self.last_update = 0
        self.last_percent = -1
    
    def parse_ffmpeg_output(self, line):
        """
        Parse FFmpeg output to extract progress
        تجزیه خروجی FFmpeg برای استخراج پیشرفت
        """
        # Extract frame number
        frame_match = re.search(r'frame=\s*(\d+)', line)
        if frame_match:
            self.current_frame = int(frame_match.group(1))
        
        # Extract fps
        fps_match = re.search(r'fps=\s*(\d+\.?\d*)', line)
        if fps_match:
            self.fps = float(fps_match.group(1))
        
        # Extract time
        time_match = re.search(r'time=(\d+):(\d+):(\d+\.?\d*)', line)
        if time_match:
            hours, minutes, seconds = time_match.groups()
            self.current_time = int(hours) * 3600 + int(minutes) * 60 + float(seconds)
            
            if self.duration and self.duration > 0:
                progress_percent = min((self.current_time / self.duration) * 100, 100)
                
                # Update only once per second to prevent overlapping
                current = time.time()
                if current - self.last_update >= 1.0:
                    self.update_progress(progress_percent)
                    self.last_update = current
    
    def update_progress(self, percent):
        """
        Update progress bar
        به‌روزرسانی نوار پیشرفت
        """
        percent_int = int(percent)
        
        # Calculate elapsed and remaining time
        elapsed = time.time() - self.start_time
        
        # Create beautiful progress bar with Unicode block characters
        bar_length = 30
        filled_length = int(bar_length * percent / 100)
        
        # Use different characters for smooth gradient effect
        filled = '━' * filled_length
        empty = '─' * (bar_length - filled_length)
        bar = f'{filled}{empty}'
        
        # Get color based on percentage range
        color = get_progress_color(percent_int)
        reset = '\033[0m'
        bold = '\033[1m'
        
        if percent < 100:
            eta = (elapsed / percent) * (100 - percent) if percent > 0 else 0
            # Beautiful single-line display with emojis and colors
            sys.stdout.write(f'\r⏳ {color}{bold}[{bar}] {percent_int:3d}%{reset} │ ⚡ {self.fps:5.1f}fps │ ⏱️  {format_time(elapsed)} │ ⏳ {format_time(eta)} ')
            sys.stdout.flush()
        else:
            sys.stdout.write(f'\r✅ {color}{bold}[{bar}] 100%{reset} │ Completed in {format_time(elapsed)}\n')
            sys.stdout.flush()
        
        self.last_percent = percent_int
    
    def close(self):
        """
        Close progress bar
        بستن نوار پیشرفت
        """
        # Print newline if not already completed
        if self.last_percent < 100:
            print()
    
    def get_elapsed_time(self):
        """
        Get elapsed time in seconds
        دریافت زمان سپری شده به ثانیه
        """
        return time.time() - self.start_time


class BatchProgressTracker:
    """
    Track progress for batch conversion
    ردیابی پیشرفت برای تبدیل دسته‌ای
    """
    
    def __init__(self, total_files):
        """
        Initialize batch progress tracker
        راه‌اندازی ردیاب پیشرفت دسته‌ای
        """
        self.total_files = total_files
        self.completed_files = 0
        self.failed_files = 0
        self.skipped_files = 0
        
        print(f"\n📦 Batch: {total_files} files")
    
    def update(self, status='completed'):
        """
        Update batch progress
        به‌روزرسانی پیشرفت دسته‌ای
        """
        if status == 'completed':
            self.completed_files += 1
        elif status == 'failed':
            self.failed_files += 1
        elif status == 'skipped':
            self.skipped_files += 1
        
        total_processed = self.completed_files + self.failed_files + self.skipped_files
        percent = int((total_processed / self.total_files) * 100)
        
        # Create simple progress bar
        bar_length = 30
        filled = int(bar_length * total_processed / self.total_files)
        bar = '█' * filled + '░' * (bar_length - filled)
        
        sys.stdout.write(f'\r[{bar}] {total_processed}/{self.total_files} | OK: {self.completed_files} | Failed: {self.failed_files}')
        sys.stdout.flush()
    
    def close(self):
        """
        Close batch progress bar
        بستن نوار پیشرفت دسته‌ای
        """
        print()  # New line after completion
    
    def get_summary(self):
        """
        Get summary of batch conversion
        دریافت خلاصه تبدیل دسته‌ای
        """
        return {
            'total': self.total_files,
            'completed': self.completed_files,
            'failed': self.failed_files,
            'skipped': self.skipped_files
        }
